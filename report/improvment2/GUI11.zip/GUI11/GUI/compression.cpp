#include "compression.h"
#include"JLcompress"

Compression::Compression(QObject *parent) : QObject(parent)
{
    // when created
}

Compression::~Compression()
{
    // when destroyed
}

void Compression::CompressDir()
{
    if(JlCompress::compressDir(ZipFile,Directory))
    {
       qDebug()<< "created:" << ZipFile;
    }
    else
    {
       qDebug()<< "Couldn't create:" << ZipFile;

    }
}

void Compression::compressFiles()
{

}
