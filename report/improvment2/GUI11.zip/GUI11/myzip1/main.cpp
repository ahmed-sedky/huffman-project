#include <QCoreApplication>
#include<QtDebug>
#include<QFile>
#include"JlCompress.h"

void CompressDir(QString ZipFile, QString Directory)
{
    if(JlCompress::compressDir(ZipFile,Directory))
    {
       qDebug()<< "created:" << ZipFile;
    }
    else
    {
       qDebug()<< "Couldn't create:" << ZipFile;

    }
}
void DecompressDir(QString ZipFile, QString Directory)
{
   QStringList list = JlCompress::extractDir(ZipFile,Directory);
   foreach (QString item, list){
       qDebug()<<"Extracted: "<<item;
   }
}
void CompressFiles(QString ZipFile, QStringList Files)
{
 if (JlCompress::compressFiles(ZipFile,Files))
  {
     qDebug()<< "created:" << ZipFile;
  }
  else
  {
     qDebug()<< "Couldn't create:" << ZipFile;

  }
}
void DecompressFiles(QString ZipFile, QStringList Files, QString Directory)
{
QStringList list = JlCompress::extractFiles(ZipFile,Files,Directory);
foreach (QString item, list){
    qDebug()<<"Extracted: "<<item;
}
}
void ListContents(QString ZipFile)
{
 QFile File(ZipFile);
 if(!File.exists())
 {
     qDebug()<<"ZipFile not found!!";
     return;
 }
 QStringList list = JlCompress::getFileList(ZipFile);
 foreach (QString item, list) {
     qDebug()<< item;
 }
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QString ZipFile ="/home/amira/GUI11/test.zip";
    QString OriginalDir ="/home/amira/GUI11/original";
    QString NewDir ="/home/amira/GUI11/NewDir";
    QString SingleFile =OriginalDir + "/NORMAL2-IM-1427-0001.pgm";

   // compress a directory
    CompressDir(ZipFile,OriginalDir);
   //list the contents of a zip file
    ListContents(ZipFile);
   //Compress a single File
    //*CompressFiles(ZipFile,QStringList()<< SingleFile);
   //decompress an archive to a directory
    //*DecompressDir(ZipFile,NewDir);
    //decompress a single file
    DecompressFiles(ZipFile,QStringList()<< "NORMAL2-IM-1431-0001.pgm",NewDir);
    return a.exec();
}
