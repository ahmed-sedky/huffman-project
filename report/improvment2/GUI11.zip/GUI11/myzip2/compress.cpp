#include "compress.h"
#include<JlCompress.h>
#include<QFile>
Compress::Compress(QObject *parent) : QObject(parent)
{
    // called when starting
}

Compress::~Compress()
{
    // called when ending
}

void Compress::CompressDir(QString ZipFile, QString Directory)
{
    if(JlCompress::compressDir(ZipFile,Directory))
    {
       qDebug()<< "created:" << ZipFile;
    }
    else
    {
       qDebug()<< "Couldn't create:" << ZipFile;
    }
}

void Compress::compressFiles(QString ZipFile, QStringList Files)
{
    if (JlCompress::compressFiles(ZipFile,Files))
     {
        qDebug()<< "created:" << ZipFile;
     }
     else
     {
        qDebug()<< "Couldn't create:" << ZipFile;
     }
}




