#include "mainwindow.h"
#include"compress.h"
#include"decompress.h"
#include"JlCompress.h"
#include <QCoreApplication>
#include<QtDebug>
#include<QFile>
#include<QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}

