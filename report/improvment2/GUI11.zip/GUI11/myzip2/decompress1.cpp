#include "decompress1.h"

Decompress1::Decompress1(QObject *parent) : QObject(parent)
{

}
