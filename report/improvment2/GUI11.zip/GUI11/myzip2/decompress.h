#ifndef DECOMPRESS_H
#define DECOMPRESS_H
#include <QtDebug>
#include <QObject>

class Decompress : public QObject
{
public:
    explicit Decompress(QObject *parent = nullptr);
    ~Decompress();
    QString ZipFile ="/home/amira/GUI11/test.zip";
    QString OriginalDir ="/home/amira/GUI11/original";
    QString NewDir ="/home/amira/GUI11/NewDir";
    QString SingleFile =OriginalDir + "/NORMAL2-IM-1427-0001.pgm";
    void DecompressDir(QString ZipFile, QString Directory);
    void DecompressFiles(QString ZipFile, QStringList Files, QString Directory);

signals:

};

#endif // DECOMPRESS_H
