#include "decompress.h"
#include<JlCompress.h>
#include<QFile>
Decompress::Decompress(QObject *parent) : QObject(parent)
{

}

Decompress::~Decompress()
{

}

void Decompress::DecompressDir(QString ZipFile, QString Directory)
{
    QStringList list = JlCompress::extractDir(ZipFile,Directory);
    foreach (QString item, list)
    {
        qDebug()<<"Extracted: "<<item;
    }
}

void Decompress::DecompressFiles(QString ZipFile, QStringList Files, QString Directory)
{
    QStringList list = JlCompress::extractFiles(ZipFile,Files,Directory);
    foreach (QString item, list)
    {
        qDebug()<<"Extracted: "<<item;
    }
}

