#ifndef COMPRESSION_H
#define COMPRESSION_H
#include <QDebug>
#include <QObject>

class Compression : public QObject
{
    Q_OBJECT
public:
    // constructor
    explicit Compression(QObject *parent = nullptr);
    //deconstructor
    ~Compression();
    QString ZipFile ="/home/amira/GUI11/test.zip";
    QString OriginalDir ="/home/amira/GUI11/original";
    QString NewDir ="/home/amira/GUI11/NewDir";
    QString SingleFile =OriginalDir + "/NORMAL2-IM-1427-0001.pgm";
    void CompressDir();
    void compressFiles();
signals:

};

#endif // COMPRESSION_H
