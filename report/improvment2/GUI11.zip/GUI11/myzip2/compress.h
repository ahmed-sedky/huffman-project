#ifndef COMPRESS_H
#define COMPRESS_H
#include <QObject>
#include<QDebug>

class Compress : public QObject
{
public:
    // constructor
    explicit Compress(QObject *parent = nullptr);
    // Deconstructor
    ~Compress();
    QString ZipFile ="/home/amira/GUI11/test.zip";
    QString OriginalDir ="/home/amira/GUI11/original";
    QString NewDir ="/home/amira/GUI11/NewDir";
    QString SingleFile =OriginalDir + "/NORMAL2-IM-1427-0001.pgm";

void CompressDir(QString ZipFile, QString Directory);
void compressFiles(QString ZipFile, QStringList Files);
signals:

};

#endif // COMPRESS_H
