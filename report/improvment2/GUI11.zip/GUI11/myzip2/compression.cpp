#include "compression.h"

Compression::Compression(QObject *parent) : QObject(parent)
{

}
