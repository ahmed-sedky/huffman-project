#ifndef DECOMPRESS1_H
#define DECOMPRESS1_H

#include <QObject>

class Decompress1 : public QObject
{
public:
    explicit Decompress1(QObject *parent = nullptr);

signals:

};

#endif // DECOMPRESS1_H
